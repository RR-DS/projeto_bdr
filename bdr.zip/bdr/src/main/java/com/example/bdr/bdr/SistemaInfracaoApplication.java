package com.example.bdr.bdr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaInfracaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaInfracaoApplication.class, args);
	}

}
